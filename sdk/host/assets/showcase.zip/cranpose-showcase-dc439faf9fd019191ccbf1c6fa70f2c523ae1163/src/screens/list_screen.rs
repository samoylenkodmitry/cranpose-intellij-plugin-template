#![allow(non_snake_case)]

use std::rc::Rc;
use std::time::Duration;

use cranpose::liquid::prelude::*;
use cranpose::prelude::*;
use cranpose_animation::prelude::*;
use cranpose_core::with_key;
use cranpose_foundation::{
    lazy::{rememberLazyListState, LazyItems, LazyListScope},
    text::TextFieldState,
};
use cranpose_ui::text::{FontWeight, TextUnit};
use cranpose_ui_graphics::Stroke;

use coroflow::FlowExt;
use cranpose_coroflow::{viewModel, CollectFlow, Handle, StateFlowCollect};

use crate::data::AppServices;
use crate::model::{BodyKind, CelestialBody, BODIES};
use crate::motion::AmbientMotion;
use crate::presentation::body_card_view_model::BodyCardViewModel;
use crate::presentation::screen_messages::ScreenMessages;
use crate::widgets::header_glass::HeaderBlurGradient;
use crate::widgets::planet::PlanetSphere;
use crate::widgets::source_link::SourceLink;
use crate::widgets::starfield::{Starfield, StarfieldScroll};
use crate::widgets::surfaces::showcase_glass;

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub enum Tab {
    Explore,
    Saved,
}

const CATEGORIES: &[(&str, Option<BodyKind>)] = &[
    ("All", None),
    ("Planets", Some(BodyKind::Planet)),
    ("Moons", Some(BodyKind::Moon)),
    ("Dwarf", Some(BodyKind::DwarfPlanet)),
    ("Star", Some(BodyKind::Star)),
    ("Exoplanet", Some(BodyKind::Exoplanet)),
];
const CONTENT_MARGIN: f32 = 20.0;
/// The widest a row is drawn. A window wider than this keeps the column
/// centred instead of stretching a card across the display.
const ROW_MAX_WIDTH: f32 = 520.0;

fn kind_color(colors: LiquidColors, kind: BodyKind) -> Color {
    match kind {
        BodyKind::Star => Color::from_rgb_u8(255, 189, 89),
        BodyKind::Planet => colors.accent,
        BodyKind::DwarfPlanet => Color::from_rgb_u8(178, 168, 214),
        BodyKind::Moon => Color::from_rgb_u8(158, 176, 196),
        BodyKind::Exoplanet => Color::from_rgb_u8(224, 118, 118),
    }
}

#[composable]
fn KindTag(kind: BodyKind) {
    let colors = liquid_colors();
    let tint = kind_color(colors, kind);
    Box(
        Modifier::empty()
            .background(Color::from_rgba_u8(
                (tint.0 * 255.0) as u8,
                (tint.1 * 255.0) as u8,
                (tint.2 * 255.0) as u8,
                46,
            ))
            .rounded_corners(7.0)
            .padding_each(7.0, 2.0, 7.0, 2.0),
        BoxSpec::default(),
        move || {
            Text(
                kind.label(),
                Modifier::empty(),
                TextStyle {
                    span_style: SpanStyle {
                        font_size: TextUnit::Sp(11.0),
                        font_weight: Some(FontWeight::SEMI_BOLD),
                        color: Some(tint),
                        ..Default::default()
                    },
                    ..Default::default()
                },
            );
        },
    );
}

#[composable]
pub(crate) fn FavoriteButton(favorite: bool, on_toggle: impl Fn() + 'static) {
    let colors = liquid_colors();
    let previous = rememberMutableStateOf(|| favorite);
    let pulse = rememberMutableStateOf(|| 1.0f32);
    LaunchedEffect(favorite, move |scope| {
        if previous.get() != favorite {
            previous.set(favorite);
            pulse.set(1.45);
            scope.launch_background(
                move |_cancel| async move { delay(Duration::from_millis(90)).await },
                move |_| {
                    pulse.set(1.0);
                },
            );
        }
    });

    let scale = animateFloatAsState(
        pulse.get(),
        spring(Spring::DampingRatioHighBouncy, Spring::StiffnessMedium),
        "favorite-scale",
    )
    .value();
    let tint = animateColorAsState(
        if favorite {
            Color::from_rgb_u8(255, 196, 60)
        } else {
            colors.tertiary_label
        },
        tween(220, Easing::EaseOut),
        "favorite-color",
    )
    .value();

    let handler = on_toggle;
    GlassIconButton(
        Modifier::empty().graphics_layer_block(move |layer| {
            layer.scale = scale;
        }),
        GlassButtonSpec::glass().with_content_color(tint),
        40.0,
        move || handler(),
        icons::STAR,
    );
}

/// One body's card. It resolves its own view model from the screen's store,
/// keyed by the body, so the list only tells it which body to show: the
/// pattern for any self-contained part of the UI with business logic of its
/// own.
#[composable]
pub fn BodyCard(
    index: usize,
    services: Handle<AppServices>,
    ambient: AmbientMotion,
    on_open: impl Fn() + 'static,
) {
    let messages = viewModel((), |_| ScreenMessages::default());
    let card = viewModel(index, move |scope| {
        let services = services.get();
        BodyCardViewModel::new(
            scope,
            index,
            services.favorites.clone(),
            services.facts.clone(),
            messages.get(),
        )
    });
    let saved = card.get().saved().collectAsStateWithLifecycle().get();
    let fact = card.get().fact().collectAsStateWithLifecycle().get();
    BodyCardContent(
        &BODIES[index],
        saved,
        fact,
        ambient,
        move || card.get().on_toggle_saved(),
        on_open,
    );
}

/// What a body card draws, given everything it shows. Previews and tests
/// compose it directly.
#[composable]
pub fn BodyCardContent(
    body: &'static CelestialBody,
    favorite: bool,
    fact: Option<String>,
    ambient: AmbientMotion,
    on_toggle_favorite: impl Fn() + 'static,
    on_open: impl Fn() + 'static,
) {
    let on_toggle_favorite: Rc<dyn Fn()> = Rc::new(on_toggle_favorite);

    let opener = on_open;
    GlassSurface(
        Modifier::empty()
            .fill_max_width()
            .clickable(move |_point| opener()),
        showcase_glass(liquid_colors(), 20.0),
        move || {
            let colors = liquid_colors();
            let on_toggle_favorite = on_toggle_favorite.clone();
            let fact = fact.clone();
            Row(
                Modifier::empty().fill_max_width().padding(14.0),
                RowSpec::default().vertical_alignment(VerticalAlignment::CenterVertically),
                move || {
                    PlanetSphere(
                        Modifier::empty().size(Size {
                            width: 60.0,
                            height: 60.0,
                        }),
                        body,
                        ambient,
                    );
                    Box(Modifier::empty().width(14.0), BoxSpec::default(), || {});
                    let fact = fact.clone();
                    Column(
                        Modifier::empty().weight(1.0),
                        ColumnSpec::default()
                            .vertical_arrangement(LinearArrangement::spaced_by(5.0)),
                        move || {
                            Row(
                                Modifier::empty().fill_max_width(),
                                RowSpec::default()
                                    .vertical_alignment(VerticalAlignment::CenterVertically),
                                move || {
                                    Text(
                                        body.name,
                                        Modifier::empty(),
                                        liquid_typography().headline.merge(&TextStyle {
                                            span_style: SpanStyle {
                                                color: Some(colors.label),
                                                ..Default::default()
                                            },
                                            ..Default::default()
                                        }),
                                    );
                                    Box(Modifier::empty().width(8.0), BoxSpec::default(), || {});
                                    KindTag(body.kind);
                                },
                            );
                            Text(
                                body.tagline,
                                Modifier::empty(),
                                liquid_typography().subheadline.merge(&TextStyle {
                                    span_style: SpanStyle {
                                        color: Some(colors.secondary_label),
                                        ..Default::default()
                                    },
                                    ..Default::default()
                                }),
                            );
                            Text(
                                fact.clone()
                                    .unwrap_or_else(|| "Looking up a fact…".to_owned()),
                                Modifier::empty(),
                                liquid_typography().caption1.merge(&TextStyle {
                                    span_style: SpanStyle {
                                        color: Some(colors.tertiary_label),
                                        ..Default::default()
                                    },
                                    ..Default::default()
                                }),
                            );
                        },
                    );
                    Box(Modifier::empty().width(6.0), BoxSpec::default(), || {});
                    let toggle = on_toggle_favorite.clone();
                    FavoriteButton(favorite, move || toggle());
                },
            );
        },
    );
}

#[composable]
fn EmptySavedState() {
    let colors = liquid_colors();
    let infinite = rememberInfiniteTransition("empty-bob");
    let bob = infinite.animateFloat(
        0.0,
        1.0,
        infiniteRepeatable(
            AnimationSpec::tween(1800, Easing::EaseInOut),
            RepeatMode::Reverse,
            StartOffset::default(),
        ),
        "bob",
    );

    Column(
        Modifier::empty()
            .fill_max_width()
            .padding_each(32.0, 96.0, 32.0, 32.0),
        ColumnSpec::default()
            .horizontal_alignment(HorizontalAlignment::CenterHorizontally)
            .vertical_arrangement(LinearArrangement::spaced_by(14.0)),
        move || {
            Box(
                Modifier::empty()
                    .size(Size {
                        width: 96.0,
                        height: 96.0,
                    })
                    .graphics_layer(move || GraphicsLayer {
                        translation_y: (bob.value() - 0.5) * 10.0,
                        ..Default::default()
                    })
                    .draw_behind(move |scope| {
                        let size = scope.size();
                        let center = Point {
                            x: size.width * 0.5,
                            y: size.height * 0.5,
                        };
                        scope.draw_circle_stroked(
                            Brush::solid(Color::from_rgba_u8(255, 255, 255, 60)),
                            center,
                            size.width * 0.42,
                            Stroke::new(2.0),
                        );
                    }),
                BoxSpec::default().content_alignment(Alignment::CENTER),
                || {
                    icons::Icon(
                        icons::STAR,
                        None,
                        36.0,
                        Color::from_rgba_u8(255, 255, 255, 90),
                    );
                },
            );
            Text(
                "No saved worlds yet",
                Modifier::empty(),
                liquid_typography().title3.merge(&TextStyle {
                    span_style: SpanStyle {
                        color: Some(colors.label),
                        ..Default::default()
                    },
                    ..Default::default()
                }),
            );
            Text(
                "Tap the star on any world in Explore to keep it here.",
                Modifier::empty(),
                liquid_typography().subheadline.merge(&TextStyle {
                    span_style: SpanStyle {
                        color: Some(colors.secondary_label),
                        ..Default::default()
                    },
                    ..Default::default()
                }),
            );
        },
    );
}

/// The main scrolling screen: search, category chips, and the list of bodies.
#[composable]
pub fn ListScreen(
    tab: Tab,
    services: Handle<AppServices>,
    favorite_count: usize,
    ambient: AmbientMotion,
    on_open: impl Fn(usize) + 'static,
) {
    let on_open: Rc<dyn Fn(usize)> = Rc::new(on_open);
    let messages = viewModel((), |_| ScreenMessages::default());
    let toast = rememberMutableStateOf(|| None::<String>);
    CollectFlow(
        (),
        messages
            .get()
            .events()
            .transform_latest(async |message: String, emitter| {
                emitter.emit(Some(message)).await;
                coroflow::delay(TOAST_DURATION).await;
                emitter.emit(None).await;
            }),
        move |message| toast.set(message),
    );
    with_key(&tab, move || {
        let list_state = rememberLazyListState();
        // Reported rather than subcomposed under a `BoxWithConstraints`: the
        // rows animate, and an animated read inside a measure-phase
        // subcomposition has no invalidation path.
        let pane_size = rememberMutableStateOf(|| Size {
            width: 0.0,
            height: 0.0,
        });
        let side_margin = CONTENT_MARGIN.max((pane_size.get().width - ROW_MAX_WIDTH) * 0.5);
        let category: MutableState<usize> = rememberMutableStateOf(|| 0usize);
        let search = remember(|| TextFieldState::new("")).with(|state| *state);
        let chip_scroll = remember(|| ScrollState::new(0.0)).with(|state| *state);
        let favorite_flags = services.get().favorites.saved().collectAsState().get();
        let query = search.text().trim().to_lowercase();
        let selected_category = category.get().min(CATEGORIES.len() - 1);
        let visible: Vec<usize> = BODIES
            .iter()
            .enumerate()
            .filter(|(index, entry)| {
                let tab_ok = match tab {
                    Tab::Explore => true,
                    Tab::Saved => favorite_flags.get(*index).copied().unwrap_or(false),
                };
                let category_ok = match CATEGORIES[selected_category].1 {
                    None => true,
                    Some(kind) => entry.kind == kind,
                };
                let query_ok = query.is_empty() || entry.name.to_lowercase().contains(&query);
                tab_ok && category_ok && query_ok
            })
            .map(|(index, _)| index)
            .collect();
        Box(
            Modifier::empty()
                .fill_max_size()
                .report_size_state(pane_size),
            BoxSpec::default(),
            move || {
                Starfield(
                    Modifier::empty().fill_max_size(),
                    StarfieldScroll::LazyList(list_state),
                    ambient,
                    favorite_count,
                );
                let colors = liquid_colors();
                let visible_keys = visible.clone();
                let visible_bodies = visible.clone();
                let query = query.clone();
                let on_open = on_open.clone();
                LazyColumn(
                    Modifier::empty().fill_max_size().padding_each(
                        side_margin,
                        0.0,
                        side_margin,
                        0.0,
                    ),
                    list_state,
                    LazyColumnSpec::default()
                        .content_padding(100.0, 128.0)
                        .vertical_arrangement(LinearArrangement::spaced_by(14.0)),
                    move |scope| {
                        scope.item(move || {
                            Row(
                                Modifier::empty().fill_max_width(),
                                RowSpec::default()
                                    .vertical_alignment(VerticalAlignment::CenterVertically)
                                    .horizontal_arrangement(LinearArrangement::spaced_by(10.0)),
                                move || {
                                    SearchField(
                                        Modifier::empty().weight(1.0),
                                        search,
                                        "Search the sky",
                                    );
                                    SourceLink();
                                },
                            );
                            Box(Modifier::empty().height(8.0), BoxSpec::default(), || {});
                            Row(
                                Modifier::empty()
                                    .fill_max_width()
                                    .horizontal_scroll(chip_scroll, false),
                                RowSpec::default()
                                    .horizontal_arrangement(LinearArrangement::spaced_by(8.0)),
                                move || {
                                    for (index, (label, _)) in CATEGORIES.iter().enumerate() {
                                        let category = category;
                                        LiquidChip(
                                            Modifier::empty(),
                                            selected_category == index,
                                            move || category.set(index),
                                            *label,
                                        );
                                    }
                                },
                            );
                        });
                        if visible_bodies.is_empty() {
                            scope.item(move || {
                                if matches!(tab, Tab::Saved)
                                    && query.is_empty()
                                    && selected_category == 0
                                {
                                    EmptySavedState();
                                } else {
                                    Text(
                                        "No worlds match that search.",
                                        Modifier::empty().padding_each(24.0, 10.0, 24.0, 0.0),
                                        liquid_typography().body.merge(&TextStyle {
                                            span_style: SpanStyle {
                                                color: Some(colors.secondary_label),
                                                ..Default::default()
                                            },
                                            ..Default::default()
                                        }),
                                    );
                                }
                            });
                        } else {
                            scope.items(
                                LazyItems::new(visible_bodies.len()).key(move |index| {
                                    visible_keys.get(index).copied().unwrap_or(index) as u64
                                }),
                                move |order| {
                                    let Some(&body_index) = visible_bodies.get(order) else {
                                        return;
                                    };
                                    let on_open = on_open.clone();
                                    BodyCard(body_index, services, ambient, move || {
                                        on_open(body_index)
                                    });
                                },
                            );
                        }
                    },
                );
                HeaderBlurGradient();
                if let Some(message) = toast.get() {
                    Toast(message);
                }
            },
        );
    });
}

/// How long a message from the screen's bus stays on screen.
const TOAST_DURATION: Duration = Duration::from_millis(1_800);

/// A message from the screen's bus, above the tab bar.
#[composable]
fn Toast(message: String) {
    let colors = liquid_colors();
    Box(
        Modifier::empty()
            .fill_max_size()
            .padding_each(24.0, 0.0, 24.0, 104.0),
        BoxSpec::default().content_alignment(Alignment::new(
            HorizontalAlignment::CenterHorizontally,
            VerticalAlignment::Bottom,
        )),
        move || {
            let message = message.clone();
            GlassSurface(Modifier::empty(), showcase_glass(colors, 18.0), move || {
                Text(
                    message.clone(),
                    Modifier::empty().padding_each(16.0, 10.0, 16.0, 10.0),
                    liquid_typography().subheadline.merge(&TextStyle {
                        span_style: SpanStyle {
                            color: Some(colors.label),
                            ..Default::default()
                        },
                        ..Default::default()
                    }),
                );
            });
        },
    );
}
